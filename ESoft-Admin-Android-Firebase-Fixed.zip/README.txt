ESoft Admin Android App
========================

Fresh Admin build based directly on the current ESoft Android project.
The Android shell, Android SDK configuration, Firebase configuration,
notifications service, icon resources, and splash resources are retained.
The only web destination is the ESoft Admin interface:
https://esoftweb.netlify.app/admin.html

GitHub Actions build:
1. Put the project contents in the ESoft Admin GitHub repository.
2. Open Actions -> Build ESoft Admin APK -> Run workflow.
3. Download the ESoft-Admin-debug-apk artifact.

Important:
- This is a DEBUG APK for testing.
- This fresh Admin variant intentionally keeps the same Android applicationId
  and Firebase Android client as the base ESoft project so the existing build
  parameters remain valid. If both User and Admin APKs must be installed on
  the same Android device at the same time, register a separate Firebase
  Android app for the Admin package and change the applicationId/package.
- The Admin page must remain protected by server-side/admin authentication;
  the Android wrapper does not provide the security boundary.
