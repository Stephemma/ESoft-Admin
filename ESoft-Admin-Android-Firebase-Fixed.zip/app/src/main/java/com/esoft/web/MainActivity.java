package com.esoft.web;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.firebase.messaging.FirebaseMessaging;

public class MainActivity extends Activity {
    private WebView webView;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestNotificationPermission();
        FirebaseMessaging.getInstance().getToken().addOnSuccessListener(token -> {
            getSharedPreferences("esoft_fcm", MODE_PRIVATE).edit().putString("fcm_token", token).apply();
            registerFcmTokenInWebView(token);
        });
        getWindow().setStatusBarColor(Color.rgb(23, 21, 18));
        getWindow().setNavigationBarColor(Color.rgb(23, 21, 18));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(23, 21, 18));
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(new NativeNotificationBridge(this), "ESoftNative");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                String js = "(function(){" +
                        "window.fireLocalNotification=function(title,body){try{if(window.ESoftNative){window.ESoftNative.showNotification(String(title||\"ESoft\"),String(body||\"You have a new notification.\"));}}catch(e){console.error(e);}};" +
                        "window.requestNotifyPermission=function(){};" +
                        "window.registerNativeFcmToken=function(uid){try{" +
                        "if(!window.ESoftNative||!uid)return;" +
                        "var token=window.ESoftNative.getFcmToken();if(!token)return;" +
                        "if(window.__esoftRegisteringToken===token+':'+uid)return;" +
                        "window.__esoftRegisteringToken=token+':'+uid;" +
                        "var u=(window.auth&&window.auth.currentUser)?window.auth.currentUser:null;" +
                        "var send=function(idToken){" +
                        "fetch('/.netlify/functions/register-fcm-token',{method:'POST',headers:{'Content-Type':'application/json','Authorization':idToken?'Bearer '+idToken:''},body:JSON.stringify({uid:uid,userId:uid,token:token,fcmToken:token,platform:'android'})})" +
                        ".then(function(r){if(!r.ok)throw new Error('HTTP '+r.status);return r.text();})" +
                        ".then(function(){console.log('Native FCM token registered');})" +
                        ".catch(function(e){console.error('FCM token registration failed',e);window.__esoftRegisteringToken=null;});" +
                        "};" +
                        "if(u&&u.getIdToken){u.getIdToken().then(send).catch(function(){send('');});}else{send('');}" +
                        "}catch(e){console.error('FCM bridge error',e);window.__esoftRegisteringToken=null;}};" +
                        "var install=function(){" +
                        "if(!window.auth||!window.ESoftNative)return false;" +
                        "if(!window.__esoftNativeAuthHook){window.__esoftNativeAuthHook=true;firebase.auth().onAuthStateChanged(function(u){if(u){window.registerNativeFcmToken(u.uid);if(window.listenUserNotifications&&window.db&&(location.pathname||'').indexOf('history.html')===-1){window.listenUserNotifications(window.db,u.uid,'navNotifBadge');}}});}" +
                        "var u=window.auth.currentUser;if(u){window.registerNativeFcmToken(u.uid);}" +
                        "return true;" +
                        "};" +
                        "var attempts=0;var timer=setInterval(function(){attempts++;if(install()||attempts>=60)clearInterval(timer);},500);" +
                        "})();";
                view.evaluateJavascript(js, null);
            }
        });

        webView.loadUrl("https://esoftweb.netlify.app/admin.html");
    }

    private void registerFcmTokenInWebView(String token) {
        if (webView == null || token == null || token.isEmpty()) return;
        webView.evaluateJavascript("(function(){try{if(window.registerNativeFcmToken&&window.auth){var u=window.auth.currentUser;if(u){window.registerNativeFcmToken(u.uid);}}}catch(e){console.error(e);}})();", null);
    }

    public void showNativeNotification(String title, String body) {
        ESoftFirebaseMessagingService.showLocalNotification(this, title, body);
    }

    public String getFcmToken() {
        return getSharedPreferences("esoft_fcm", MODE_PRIVATE).getString("fcm_token", "");
    }

    private void requestNotificationPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1001);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }
}
